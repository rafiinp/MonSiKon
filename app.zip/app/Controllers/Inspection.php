<?php

namespace App\Controllers;

use App\Models\InspectionModel;
use App\Models\ContainerModel;
use App\Models\UserModel;
use CodeIgniter\RESTful\ResourcePresenter;
use CodeIgniter\HTTP\CURLRequest;

class Inspection extends ResourcePresenter
{
    protected $modelName = 'App\Models\InspectionModel';
    protected $helpers = ['form'];

    public function __construct()
    {
        $this->containerModel = new ContainerModel();
        $this->userModel = new UserModel();
        $this->inspectionModel = new InspectionModel();
         $this->curl = \Config\Services::curlrequest();
    }

    // List all inspections
    public function index()
    {
        $data['inspections'] = $this->model->getAllInspections();
        return view('inspection/admin/index', $data);
    }

    // Show the scheduling form
    public function show($id = null)
    {
        // Redirect to the schedule method for creating new inspection
        return $this->schedule();
    }

    // Render the scheduling form
    public function schedule()
{
    $data['containers'] = $this->containerModel->findAll();
    $data['user'] = $this->userModel->where('role', 'surveyor')->findAll(); // Change this line
    return view('inspection/admin/schedule', $data);
}

    

    // Process the creation of a new inspection schedule
    public function create()
    {
        $data = [
            'container_id' => $this->request->getPost('container_id'),
            'surveyor_id' => $this->request->getPost('surveyor_id'),
            'scheduled_date' => $this->request->getPost('scheduled_date'),
            'status' => 'pending'
        ];

        // Validate the data
        if ($this->model->insert($data)) {
            return redirect()->to('inspection')->with('success', 'Inspection scheduled successfully');
        }

        // If validation fails
        return redirect()->back()->withInput()->with('errors', $this->model->errors());
    }

    // Surveyor Dashboard
    public function surveyorDashboard()
    {
        $surveyor_id = session()->get('id_user');
        $data['inspections'] = $this->model->getScheduledInspections($surveyor_id);
        return view('inspection/surveyor/dashboard', $data);
    }

    // Perform Inspection
    public function perform($id = null)
{
    // Ensure $id is not null and is numeric
    if ($id === null || !is_numeric($id)) {
        return redirect()->back()->with('error', 'Invalid inspection ID');
    }

    // Find the inspection using find() method
    $inspection = $this->model->find($id);
    
    if (!$inspection) {
        return redirect()->back()->with('error', 'Inspection not found');
    }
    
    // Get container details safely using a query builder approach
    $container = (object) $this->containerModel->where('id_container', $inspection->container_id)->first();
    
    // Ensure container is found
    if (!$container) {
        return redirect()->back()->with('error', 'Container not found');
    }
    
    // Pass both inspection and container to the view
    return view('inspection/surveyor/perform', [
        'inspection' => $inspection,
        'container' => $container
    ]);
}

    // Submit Inspection
    public function update($id = null)
{
    // Handle photo upload
    $photo = $this->request->getFile('inspection_photo');
    $photoName = null;

    if ($photo && $photo->isValid() && !$photo->hasMoved()) {
        $photoName = $photo->getRandomName();
        $photo->move(FCPATH . 'upload_result', $photoName);
    }

    // Handle container code image upload and OCR processing
    $codeImage = $this->request->getFile('container_code_image');
    $containerCodeText = '';

    if ($codeImage && $codeImage->isValid() && !$codeImage->hasMoved()) {
        // Use a temporary file path
        $filePath = $codeImage->getTempName();

        // Perform OCR using Tesseract
        try {
            // Ensure OCR command includes proper error handling
            $ocrOutput = shell_exec("tesseract $filePath stdout 2>&1");
            
            // More robust cleaning of OCR output
            $containerCodeText = preg_replace('/[^a-zA-Z0-9]/', '', trim($ocrOutput));
            
            // Log the raw OCR output for debugging
            log_message('info', 'OCR Raw Output: ' . $ocrOutput);
            log_message('info', 'Cleaned OCR Text: ' . $containerCodeText);
        } catch (Exception $e) {
            // Log the full error
            log_message('error', 'OCR Error: ' . $e->getMessage());
            return redirect()->back()->with('error', 'OCR failed: ' . $e->getMessage());
        }
    }

    // If no OCR result, try to get manually entered container code
    if (empty($containerCodeText)) {
        $containerCodeText = $this->request->getPost('container_code');
    }

    $data = [
        'result' => $this->request->getPost('result'),
        'inspection_photo' => $photoName,
        'container_code' => $containerCodeText, // Save OCR or manually entered result
        'status' => 'completed'
    ];

    // Ensure data is not empty before updating
    if (!empty($containerCodeText) || !empty($photoName) || !empty($data['result'])) {
        if ($this->model->update($id, $data)) {
            return redirect()->to('inspection')->with('success', 'Inspection completed successfully');
        }
    }

    return redirect()->back()->withInput()->with('error', 'Failed to update inspection. Please check your inputs.');
}
}