<?php

namespace App\Controllers;

use App\Models\LogUserModel;
use App\Models\UserModel;
use CodeIgniter\API\ResponseTrait;
use CodeIgniter\HTTP\ResponseInterface;
use CodeIgniter\RESTful\ResourcePresenter;

class User extends ResourcePresenter
{  
    protected $format = 'json';

    use ResponseTrait;

    protected $modelName = 'App\Models\UserModel';

    protected $UserModel;
    protected $LogUserModel;

    public function __construct()
    {
        $this->UserModel = new UserModel;
        $this->LogUserModel = new LogUserModel();
    }

    /**
     * Present a view of resource objects.
     *
     * @return ResponseInterface
     */
    public function index()
    {
        $keyword = $this->request->getGet('keyword');
        $data = $this->UserModel->getPaginatedUser(50, $keyword);
        return view('user/index', $data);
    }

    /**
     * Present a view to present a specific resource object.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function show($id = null)
    {
        //
    }

    /**
     * Present a view to present a new single resource object.
     *
     * @return ResponseInterface
     */
    public function new()
    {
        return view('user/new');
    }

    /**
     * Process the creation/insertion of a new resource object.
     * This should be a POST.
     *
     * @return ResponseInterface
     */
    public function create()
    {
        $photo = $this->request->getFile('photo_user');

        if ($photo !== null && $photo->isValid() && !$photo->hasMoved()) {
            $uploadPath = FCPATH . 'upload_user';
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0777, true);
            }

            $photoName = time() . '_' . $photo->getClientName();
            $photo->move($uploadPath, $photoName);

            $userData = [
                'photo_user' => $photoName,
                'name_user' => $this->request->getVar('name_user'),
                'email_user' => $this->request->getVar('email_user'),
                'password_user' => password_hash($this->request->getVar('password_user'), PASSWORD_BCRYPT),
                'role' => $this->request->getVar('role'),
            ];

            // Use UserModel instead of model
            $this->UserModel->insert($userData);
            
            // Ubah redirect ke named route 'user'
            return redirect()->to(base_url('user'))->with('success', 'Data Berhasil Disimpan');
        } else {
            return redirect()->back()->withInput()->with('error', 'Failed to upload photo.');
        }
    }


    /**
     * Present a view to edit the properties of a specific resource object.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function edit($id = null)
    {
        $user = $this->UserModel->where('id_user', $id)->first();
        if (is_object($user)) {
            $data['admin'] = $user;
            return view('user/edit', $data);
        } else {
            throw \CodeIgniter\Exceptions\PageNotFoundException::forPageNotFound();
        }
    }

    /**
     * Process the updating, full or partial, of a specific resource object.
     * This should be a POST.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function update($id = null)
    {
        // Ambil file foto yang diunggah
        $photo = $this->request->getFile('photo_user');

        // Ambil data produk berdasarkan ID
        $user = $this->UserModel->find($id);

        // Periksa apakah file foto valid dan sudah diunggah
        if ($photo !== null && $photo->isValid() && !$photo->hasMoved()) {
            // Direktori penyimpanan di dalam direktori public
            $uploadPath = FCPATH . 'upload_user'; // Simpan di direktori public/upload_product
            if (!is_dir($uploadPath)) {
                mkdir($uploadPath, 0777, true); // Buat direktori dengan izin tertinggi jika belum ada
            }

            // Generate nama unik untuk file foto
            $photoName = time() . '_' . $photo->getClientName();

            // Pindahkan file foto ke direktori penyimpanan
            $photo->move($uploadPath, $photoName);

            // Siapkan data untuk disimpan ke database
            $data = [
                'name_user' => $this->request->getVar('name_user'),
                'email_user' => $this->request->getVar('email_user'),
                'password_user' => password_hash($this->request->getVar('password_user'), PASSWORD_BCRYPT),
                'role' => $this->request->getVar('role'),
                'photo_user' => $photoName, // Simpan nama file foto ke dalam data produk
            ];

            // Update data produk ke database
            $this->UserModel->update($id, $data);
            $this->logAction('update', 'Data User has been updated with the name: ' . $user->name_user);

            // Redirect ke halaman produk dengan pesan sukses
            return redirect()->to(site_url('user'))->with('success', 'Data Berhasil Diupdate');
        } else {
            // Jika file tidak diunggah atau tidak valid, update data produk tanpa mengubah foto
            $data = [
                'name_user' => $this->request->getVar('name_user'),
                'email_user' => $this->request->getVar('email_user'),
                'password_user' => password_hash($this->request->getVar('password_user'), PASSWORD_BCRYPT),
                'role' => $this->request->getVar('role'),

            ];

            // Update data produk ke database tanpa mengubah foto
            $this->UserModel->update($id, $data);
            $this->logAction('update', 'Data User has been updated with the name: ' . $user->name_user);

            // Redirect ke halaman produk dengan pesan sukses
            return redirect()->to(site_url('user'))->with('success', 'Data Berhasil Diupdate');
        }
    }

    /**
     * Present a view to confirm the deletion of a specific resource object.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function remove($id = null)
    {
        //
    }

    /**
     * Process the deletion of a specific resource object.
     *
     * @param int|string|null $id
     *
     * @return ResponseInterface
     */
    public function delete($id = null)
    {
        // Dapatkan data user berdasarkan ID
        $user = $this->UserModel->find($id);

        // Periksa apakah data user ditemukan
        if (!$user) {
            return redirect()->to(site_url('userTabel'))->with('error', 'Admin not found');
        }

        // Dapatkan nama file gambar admin
        $photoName = $user->photo_user;

        // Hapus data user dari database
        $this->UserModel->delete($id);

        // Hapus file gambar dari folder uploads
        $uploadPath = FCPATH . 'upload_user/' . $photoName;
        if (file_exists($uploadPath)) {
            unlink($uploadPath);
        }

        $this->logAction('delete', 'Admin has been deleted with the name: ' . $user->name_user);

        // Redirect ke halaman user dengan pesan sukses
        return redirect()->to(site_url('userTabel'))->with('success', 'Data berhasil dihapus');
    }

    private function logAction($action, $message)
    {
        // Get the currently logged-in admin ID
        $id_user = session()->get('id_user');

        // Prepare log data
        $logData = [
            'id_user' => $id_user,
            'action'   => $message
        ];

        // Insert log into database
        $this->LogUserModel->insert($logData);
    }

}
 