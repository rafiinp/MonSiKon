<?= $this->extend('layout/default') ?>

<?= $this->section('title') ?>
    <title>Perform Inspection | MonSiKon</title>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
<section class="section">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="#">MonSiKon</a></li>
                            <li class="breadcrumb-item"><a href="<?= site_url('surveyor/dashboard') ?>">Surveyor Dashboard</a></li>
                            <li class="breadcrumb-item active">Perform Inspection</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Inspection for Container <?= $container->container_number ?></h4>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <form action="<?= site_url('inspection/update/'.$inspection->id_inspection) ?>" method="POST" enctype="multipart/form-data">
                            <?= csrf_field() ?>

                            <div class="row">
                                <!-- Container Details Section -->
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label class="form-label">Container Details</label>
                                        <div class="border p-3 rounded">
                                            <p><strong>Container Number:</strong> <?= $container->container_number ?></p>
                                            <p><strong>Container Type:</strong> <?= $container->type ?></p>
                                            <p><strong>Capacity:</strong> <?= $container->capacity ?></p>
                                            <p><strong>Current Status:</strong> 
                                                <span class="badge bg-<?= $container->status == 'available' ? 'success' : 'warning' ?>">
                                                    <?= ucfirst($container->status) ?>
                                                </span>
                                            </p>
                                        </div>
                                    </div>

     <!-- Container Code Input Section -->
<div class="mb-3">
    <label for="container_code_image" class="form-label">Upload Container Code or Enter Manually</label>
    <div class="input-group mb-2">
        <input type="file" class="form-control" id="container_code_image" name="container_code_image" accept="image/*">
    </div>
    <div class="input-group">
        <span class="input-group-text"><i class="mdi mdi-barcode"></i></span>
        <input type="text" class="form-control" id="container_code" name="container_code" placeholder="Manually enter container code">
    </div>
    <small class="text-muted">Upload an image for OCR or enter the code manually</small>
</div>
                                </div>

                                <!-- Inspection Photo Section -->
                                <div class="col-lg-6">
                                    <div class="mb-3">
                                        <label for="inspection_photo" class="form-label">Inspection Photo</label>
                                        <div class="card border-dashed border-2 text-center p-4">
                                            <input type="file" name="inspection_photo" id="inspection_photo" class="form-control" accept="image/*">
                                            <small class="text-muted">Upload container inspection photo</small>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Inspection Result Section -->
                            <div class="row">
                                <div class="col-12">
                                    <div class="mb-3">
                                        <label for="result" class="form-label">Inspection Result</label>
                                        <textarea class="form-control" id="result" name="result" rows="5" placeholder="Describe the condition of the container, any damages, or issues found"></textarea>
                                    </div>
                                </div>
                            </div>

                            <!-- Submit and Cancel Buttons -->
                            <div class="row">
                                <div class="col-12">
                                    <div class="text-end">
                                        <button type="submit" class="btn btn-success">
                                            <i class="mdi mdi-check"></i> Complete Inspection
                                        </button>
                                        <a href="<?= site_url('surveyor/dashboard') ?>" class="btn btn-light">Cancel</a>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?= $this->section('scripts') ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
<script src='https://unpkg.com/tesseract.js@v2.1.0/dist/tesseract.min.js'></script>
<script>
$(document).ready(function() {
    $('#scanContainerCode').click(function() {
        // Trigger file input for OCR
        $('#ocrFileInput').click();
    });

    $('#ocrFileInput').change(function(e) {
        const file = e.target.files[0];
        
        // Show loading
        $('#scanContainerCode').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...');

        // Perform OCR
        Tesseract.recognize(
            file,
            'eng', // English language
            { 
                logger: m => {
                    console.log('OCR Progress:', m.progress)
                }
            }
        ).then(({ data: { text } }) => {
            // Clean and set container code
            const cleanedText = text.replace(/[^a-zA-Z0-9]/g, '').trim();
            $('#container_code').val(cleanedText);
            
            // Reset button
            $('#scanContainerCode').html('<i class="mdi mdi-camera"></i> Scan');
        }).catch(err => {
            console.error(err);
            alert('OCR Processing Failed');
            $('#scanContainerCode').html('<i class="mdi mdi-camera"></i> Scan');
        });
    });
});
</script>
<?= $this->endSection() ?>
<?= $this->endSection() ?>