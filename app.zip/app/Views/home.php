<?= $this->extend('layout/default') ?>

<?= $this->section('title') ?>
<title>Dashboard | MonSiKon</title>
<?= $this->endSection(); ?>

<?= $this->section('content'); ?>
<section class="section">
    <div class="container-fluid">

        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <form class="d-flex">
                            <div class="input-group">
                                <input type="text" class="form-control form-control-light" id="dash-daterange">
                                <span class="input-group-text bg-primary border-primary text-white">
                                    <i class="mdi mdi-calendar-range font-13"></i>
                                </span>
                            </div>
                            <a href="javascript: void(0);" class="btn btn-primary ms-2">
                                <i class="mdi mdi-autorenew"></i>
                            </a>
                            <a href="javascript: void(0);" class="btn btn-primary ms-1">
                                <i class="mdi mdi-filter-variant"></i>
                            </a>
                        </form>
                    </div>
                    <h4 class="page-title">Welcome to Dashboard :)</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->

        <div class="row">
            <div class="col-xl-5 col-lg-6">

                <div class="row">
                <div class="col-lg-6">
                        <div class="card widget-flat">
                            <div class="card-body">
                                <div class="float-end">
                                    <i class="mdi mdi-account-multiple widget-icon"></i>
                                </div>
                                <!-- <div class="mb-1 text">
                                <i class="uil-file-check" style="font-size: 24px;"></i>
                                </div> -->

                                <h3 class="mt-3 mb-3">1</h3>
                                <!-- <p class="mb-0 text-muted">
                                    <span class="text-success me-2"><i class="mdi mdi-arrow-up-bold"></i>  %</span>
                                    <span class="text-nowrap">Since last day</span>
                                </p> -->
                                <h5 class="text-muted fw-normal mt-1" title="Number of Customers">Inspected Completed</h5>
                            </div> <!-- end card-body-->
                        </div> <!-- end card-->
                    </div> <!-- end col-->

                    <div class="col-lg-6">
                        <div class="card widget-flat">
                            <div class="card-body">
                                <div class="float-end">
                                    <i class="mdi mdi-bank-transfer widget-icon"></i>
                                </div>
                                <!-- <div class="mb-2 text">
                                <i class="uil-file-times" style="font-size: 24px;"></i>
                                </div> -->

                                <h3 class="mt-3 mb-3">4</h3>
                                <!-- <p class="mb-0 text-muted">
                                        <span class="text-success me-2"><i class="mdi mdi-arrow-up-bold"></i>  %</span>
                                        <span class="text-nowrap">Since last day</span>
                                </p> -->
                                <h5 class="text-muted fw-normal mt-0" title="Number of Orders">Uninspected</h5>
                            </div> <!-- end card-body-->
                        </div> <!-- end card-->
                    </div> <!-- end col-->
                </div> <!-- end row -->

                <!-- <div class="row">
                    <div class="col-lg-6">
                        <div class="card widget-flat">
                            <div class="card-body">
                                <div class="float-end">
                                    <i class="mdi mdi-cash widget-icon"></i>
                                </div>
                                <h5 class="text-muted fw-normal mt-0" title="Average Revenue">Revenue</h5>
                                <h3 class="mt-3 mb-3">
                                    Rp 
                                </h3>
                                <p class="mb-0 text-muted"> -->
                                    <!-- <span class="text-success me-2"><i class="mdi mdi-arrow-up-bold"></i> 7.00%</span>
                                    <span class="text-nowrap">Since last month</span> -->
                                </p>
                            </div> <!-- end card-body-->
                        </div> <!-- end card-->
                    </div> <!-- end col-->

                    <!-- <div class="col-lg-6">
                        <div class="card widget-flat">
                            <div class="card-body">
                                <div class="float-end">
                                    <i class="mdi mdi-pulse widget-icon"></i>
                                </div>
                                <h5 class="text-muted fw-normal mt-0" title="Growth">Product</h5>
                                <h3 class="mt-3 mb-3"></h3> -->
                                <!-- <p class="mb-0 text-muted">
                                    <span class="text-success me-2"><i class="mdi mdi-arrow-up-bold"></i> 4.87%</span>
                                    <span class="text-nowrap">Since last month</span>
                                </p> -->
                            </div> <!-- end card-body-->
                        </div> <!-- end card-->
                    </div> <!-- end col-->
                </div> <!-- end row -->

            </div> <!-- end col -->

            <!-- <div class="col-xl-7 col-lg-6">
                <div class="card card-h-100">
                <div class="card-body">
    <div class="dropdown float-end">
        <a href="#" class="dropdown-toggle arrow-none card-drop" data-bs-toggle="dropdown" aria-expanded="false">
            <i class="mdi mdi-dots-vertical"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-end"> -->
            <!-- item-->
            <a href="javascript:void(0);" class="dropdown-item">Import</a>
        </div>
    </div>

    <!-- <h4 class="header-title mb-3">Monthly Income Chart</h4>
    <div>
        <canvas id="pembelianChart"></canvas>
    </div>
    <script src="<?= base_url() ?>/template/assets/js/chartbar.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            var ctx = document.getElementById('pembelianChart').getContext('2d');
            fetch('')
                .then(response => response.json())
                .then(data => {
                    new Chart(ctx, {
                        type: 'bar',
                        data: {
                            labels: data.labels,
                            datasets: [{
                                label: 'Total Pembelian',
                                data: data.values,
                                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                                borderColor: 'rgba(54, 162, 235, 1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            scales: {
                                y: {
                                    beginAtZero: true,
                                    ticks: {
                                        callback: function(value) {
                                            return 'Rp ' + value.toLocaleString();
                                        }
                                    }
                                }
                            },
                            plugins: {
                                legend: {
                                    display: false
                                }
                            }
                        }
                    });
                });
        });
    </script> -->
</div> <!-- end card-body-->





                    </div> <!-- end card-body-->
                </div> <!-- end card-->

            </div> <!-- end col -->
        </div>
        <!-- end row -->

        <div class="row">
            <div class="col-xl-12 col-lg-12 order-lg-2 order-xl-1">
                <div class="card">
                    <div class="card-body">
                        <!-- <a href="" class="btn btn-sm btn-link float-end">Export
                            <i class="mdi mdi-download ms-1"></i>
                        </a> -->
                        <!-- <h4 class="header-title mt-2 mb-3">Top Selling Products</h4>

                        <div class="table-responsive">
                            <table class="table table-centered table-nowrap table-hover mb-0">
                                <tbody>
                                    <?php if (isset($topSellingProducts)) : ?>
                                        <?php foreach ($topSellingProducts as $product) : ?>
                                            <tr>
                                                <td>
                                                    <h5 class="font-14 my-1 fw-normal"><?= esc($product->name_product) ?></h5>
                                                    <span class="text-muted font-13"><?= date('d F Y', strtotime($product->created_at)) ?></span>
                                                </td>
                                                <td>
                                                    <h5 class="font-14 my-1 fw-normal">Rp <?= number_format($product->price_product, 0, '.', ',') ?></h5>
                                                    <span class="text-muted font-13">Price</span>
                                                </td>
                                                <td>
                                                    <h5 class="font-14 my-1 fw-normal"><?= esc($product->order_count_product) ?></h5>
                                                    <span class="text-muted font-13">Order Count</span>
                                                </td>
                                                <td>
                                                    <h5 class="font-14 my-1 fw-normal">Rp <?= number_format($product->price_product * $product->order_count_product, 0, '.', ',') ?></h5>
                                                    <span class="text-muted font-13">Amount</span>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table> -->
                        </div> <!-- end table-responsive-->



                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col-->
            <!-- end col -->

        </div>
    </div>


</section>
<?= $this->endSection(); ?>