<?php

namespace App\Database\Migrations;

use CodeIgniter\Database\Migration;

class CreateLogUser extends Migration
{
    public function up()
    {
        $this->forge->addField([
            'id_log_user' => [
                'type'           => 'INT',
                'constraint'     => 20,
                'unsigned'       => true,
                'auto_increment' => true,
            ],
            'id_user' => [
                'type'           => 'INT',
                'constraint'     => 20,
                'unsigned'       => true,
            ],
            'action' => [
                'type'       => 'VARCHAR',
                'constraint' => '255',
            ],
            'created_at datetime default current_timestamp',
            'updated_at datetime default current_timestamp on update current_timestamp',
            'deleted_at datetime default null',
        ]);
        $this->forge->addKey('id_log_user', true);
        $this->forge->addForeignKey('id_user', 'user', 'id_user');
        $this->forge->createTable('log_user');
    }

    public function down()
    {
        $this->forge->dropForeignKey('log_user', 'log_user_id_user_foreign');
        $this->forge->dropTable('log_user');
    }
}
