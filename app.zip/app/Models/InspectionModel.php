<?php

namespace App\Models;

use CodeIgniter\Model;

class InspectionModel extends Model
{
    protected $table = 'inspections';
    protected $primaryKey = 'id_inspection';
    protected $returnType = 'object';
    protected $allowedFields = [
        'container_id', 
        'scheduled_date', 
        'surveyor_id', 
        'status', 
        'result', 
        'inspection_photo', 
        'container_code'
    ];

    protected $useTimestamps = true;
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';
    protected $deletedField = 'deleted_at';

    protected $validationRules = [
        'container_id'      => 'required|numeric|exists[containers.id_container]',
        'scheduled_date'    => 'required|valid_date',
        'surveyor_id'       => 'required|numeric|exists[user.id_user]',
        'status'            => 'permit_empty|in_list[pending,completed]',
    ];

    protected $validationMessages = [
        'container_id' => [
            'exists' => 'The selected container does not exist.'
        ],
        'surveyor_id' => [
            'exists' => 'The selected surveyor does not exist.'
        ]
    ];

    // Get all inspections with related container and surveyor details
    public function getAllInspections()
    {
        return $this->select('inspections.*, containers.container_number, user.name_user as surveyor_name')
                    ->join('containers', 'containers.id_container = inspections.container_id')
                    ->join('user', 'user.id_user = inspections.surveyor_id')
                    ->findAll();
    }

    // Get scheduled inspections for a specific surveyor
    public function getScheduledInspections($surveyor_id)
{
    return $this->select('inspections.*, containers.container_number')
                ->join('containers', 'containers.id_container = inspections.container_id')
                ->where('inspections.surveyor_id', $surveyor_id)
                ->where('inspections.status', 'pending')
                ->findAll();
}
}