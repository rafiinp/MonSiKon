<?php

namespace App\Models;

use CodeIgniter\Model;

class LogUserModel extends Model
{
    protected $table            = 'log_user';
    protected $primaryKey       = 'id_log_user';
    protected $returnType       = 'object';
    protected $allowedFields    = ['id_user', 'action'];
    protected $useAutoIncrement = true;
    protected $useTimestamps = true;
    protected $useSoftDeletes   = false;

    function getAll() {
        $builder = $this->db->table('log_user');
        $builder->join('user', 'user.id_user = log_user.id_user');
        $builder->where('log_user.deleted_at', null); // Filter data yang belum dihapus secara logis
        $query = $builder->get();
        return $query->getResult();
    }

    public function getPaginatedLogUser ($num, $keyword = null) {
        $builder = $this->builder();
        if(!empty($keyword)) {
            $builder->like('name_user', $keyword);
            $builder->orlike('action', $keyword);
        }

        return [
            'log_user' => $this->paginate($num),
            'pager' => $this->pager,
        ];
    }
}
