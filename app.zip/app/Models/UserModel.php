<?php

namespace App\Models;

use CodeIgniter\Model;

class UserModel extends Model
{
    protected $table            = 'user';
    protected $primaryKey       = 'id_user';
    protected $returnType       = 'object';
    protected $allowedFields    = ['photo_user', 'name_user', 'email_user', 'password_user', 'role'];
    protected $useAutoIncrement = true;
    protected $protectFields    = true;
    protected $useTimestamps = true;
    protected $useSoftDeletes   = false;
    

    public function getPaginatedUser ($num, $keyword = null)
    {
        $builder = $this->builder();
        if($keyword != '') {
            $builder->orLike('name_user', $keyword);
            $builder->orLike('email_user', $keyword);
            $builder->orLike('role', $keyword);
        }

        return [
            'user' => $this->paginate($num),
            'pager' => $this->pager,
        ];

    }
}
